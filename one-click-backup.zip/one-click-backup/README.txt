
```markdown
# 🔁 One-Click Manjaro Backup & Restore USB Creator

Create a **bootable USB** that can both:

✅ Back up your entire Manjaro system  
✅ Restore it to a new or existing disk

> 🧠 This script does EVERYTHING for you — no manual prep or typing required.

---

## 🧩 What You Need

- A 128GB USB stick (all data will be erased)
- Internet connection (to download Clonezilla ISO)
- You're running **Manjaro Linux**
- Your internal system disk is: `/dev/nvme1n1` ✅
- You want to restore it to: `/dev/nvme0n1` ✅

---

## 🚀 How to Use This Script (All-in-One)

### ✅ Step 1: Run the Script

In your Manjaro system, run:

```bash
chmod +x make_backup_usb.sh
sudo ./make_backup_usb.sh
```

That’s it! The script will do everything below 👇

---

## 🔧 PART 1: What Happens Automatically in `make_backup_usb.sh`

### 1. Downloads Clonezilla Live ISO
- From SourceForge
- Saved as `clonezilla.iso` in `~/clonezilla-work/`

### 2. Extracts the ISO
- Mounts the ISO
- Copies its contents to `iso/`
- Extracts the SquashFS filesystem to `extract/`

### 3. Adds Two Auto-Run Scripts:
#### ✅ `manjaro_backup.sh`
- Clones your current Manjaro system (`/dev/nvme1n1`) to the USB (`/dev/sda`)
- Partitions, formats, and installs GRUB
- Makes the USB bootable

#### ✅ `restore_to_nvme0n1.sh`
- Clones the USB system back to your internal drive (`/dev/nvme0n1`)
- Partitions, formats, and installs GRUB
- Makes the internal disk bootable

### 4. Adds a Dual Boot Menu to the USB:

```
Backup Manjaro to USB (auto)
Restore Manjaro to Internal Disk (auto)
```

- Select one at boot
- No typing required

### 5. Rebuilds the ISO
- Includes your scripts + updated boot menu

### 6. Flashes the ISO to your 128GB USB (`/dev/sda`)
- **This erases all data on the USB**
- Uses `dd` to flash the bootable ISO

---

## 💾 PART 2: How to Use the USB

### ✅ Step 1: Reboot and Boot from the USB

- Insert your newly created USB
- Reboot your PC
- Enter boot menu (`F2`, `F10`, `F12`, `Esc`, or `Del`)
- Select the USB (e.g., `UEFI: SanDisk`)

---

## 🧙 Boot Menu Options

Once the USB boots, you'll see:

### 1. `Backup Manjaro to USB (auto)`
- Clones your full system (`/dev/nvme1n1`) onto the USB
- Makes the USB fully bootable with GRUB

### 2. `Restore Manjaro to Internal Disk (auto)`
- Clones your USB system to your internal 1.8TB disk (`/dev/nvme0n1`)
- Makes the internal disk bootable again

> 📌 Both scripts ask for confirmation (`Type YES to continue`) before doing anything.

---

## ✅ Result

With this USB, you can:

- Back up your Manjaro system at any time
- Restore it easily to any internal disk
- Boot your system directly from USB when needed

---

## 🛠 No Setup Needed

You don’t need to:
- Manually install packages ✅
- Manually create partitions ✅
- Type any scripts ✅
- Modify GRUB or bootloaders manually ✅

Everything is handled for you by the script.

