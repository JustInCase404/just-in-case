#!/bin/bash
# 🎙️ Manjaro One-Click Backup USB Creator (Backup + Restore Dual Boot Menu)

set -e

# CONFIG
SOURCE_DISK="/dev/nvme1n1"
BACKUP_USB="/dev/sda"
RESTORE_TARGET="/dev/nvme0n1"
WORKDIR="$HOME/clonezilla-work"
CLONEZILLA_URL="https://downloads.sourceforge.net/project/clonezilla/clonezilla_live_stable/3.1.2-9/clonezilla-live-3.1.2-9-amd64.iso"
ISO_NAME="clonezilla.iso"
ISO_OUT="clonezilla-dualboot.iso"

echo "📦 Preparing working directory..."
mkdir -p "$WORKDIR"
cd "$WORKDIR"

# ⏏️ Unmount ISO if already mounted
echo "⏏️ Checking and unmounting previous ISO (if any)..."
MOUNTED=$(mount | grep "mnt" || true)
if [[ -n "$MOUNTED" ]]; then
  sudo umount mnt || sudo umount -l mnt
fi

# 🧹 Clean up previous build folders
echo "🧹 Cleaning previous build folders..."
sudo rm -rf mnt iso extract squashfs-root newfilesystem.squashfs
mkdir -p mnt iso extract

# 📥 Download Clonezilla ISO
wget -O "$ISO_NAME" "$CLONEZILLA_URL"

# 📂 Extract ISO
sudo mount -o loop "$ISO_NAME" mnt
cp -a mnt/* iso/
sudo unsquashfs mnt/live/filesystem.squashfs
cp -r squashfs-root extract
sudo umount mnt

# 📝 Add backup and restore scripts
sudo mkdir -p extract/home/partimag

# 🧪 BACKUP SCRIPT
sudo tee extract/home/partimag/manjaro_backup.sh > /dev/null <<EOF
#!/bin/bash
set -e
SOURCE_DISK="$SOURCE_DISK"
DEST_DISK="$BACKUP_USB"

echo "⚠️ This will ERASE \$DEST_DISK and clone \$SOURCE_DISK onto it."
read -rp "Type YES to continue: " confirm
[[ "\$confirm" != "YES" ]] && echo "Cancelled." && exit 1

sgdisk --zap-all "\$DEST_DISK"
parted -s "\$DEST_DISK" mklabel gpt
parted -s "\$DEST_DISK" mkpart primary 0% 100%
sleep 2
mkfs.ext4 "\${DEST_DISK}1" -L manjaro_backup

mkdir -p /mnt/usb_backup
mount "\${DEST_DISK}1" /mnt/usb_backup

ocs-sr -q2 -j2 -z1p -i 2000 -sc -sfsck savedisk "manjaro_clone" "\$SOURCE_DISK"

mount --bind /dev /mnt/usb_backup/dev
mount --bind /proc /mnt/usb_backup/proc
mount --bind /sys /mnt/usb_backup/sys
chroot /mnt/usb_backup grub-install --target=i386-pc --recheck "\$DEST_DISK"
chroot /mnt/usb_backup update-grub

umount -R /mnt/usb_backup
echo "✅ Backup complete. USB is bootable."
EOF

# 🔁 RESTORE SCRIPT
sudo tee extract/home/partimag/restore_to_nvme0n1.sh > /dev/null <<EOF
#!/bin/bash
set -e
SOURCE_DISK="$BACKUP_USB"
DEST_DISK="$RESTORE_TARGET"

echo "⚠️ This will ERASE \$DEST_DISK and restore Manjaro from \$SOURCE_DISK."
read -rp "Type YES to continue: " confirm
[[ "\$confirm" != "YES" ]] && echo "Cancelled." && exit 1

sgdisk --zap-all "\$DEST_DISK"
parted -s "\$DEST_DISK" mklabel gpt
parted -s "\$DEST_DISK" mkpart primary 0% 100%
sleep 2
mkfs.ext4 "\${DEST_DISK}1" -L manjaro_restored

mkdir -p /mnt/restore_target
mount "\${DEST_DISK}1" /mnt/restore_target

ocs-sr -g auto -e1 auto -e2 -r -j2 -k1 -p true -scr -icds restoredisk "manjaro_clone" "\$DEST_DISK"

mount --bind /dev /mnt/restore_target/dev
mount --bind /proc /mnt/restore_target/proc
mount --bind /sys /mnt/restore_target/sys
chroot /mnt/restore_target grub-install --target=i386-pc --recheck "\$DEST_DISK"
chroot /mnt/restore_target update-grub

umount -R /mnt/restore_target
echo "✅ Restore complete. Internal disk is now bootable."
EOF

sudo chmod +x extract/home/partimag/*.sh

# 🦝 Add boot menu entries
echo "🦝 Patching boot menu entries..."
if [[ -f iso/isolinux/isolinux.cfg ]]; then
  ISOLINUX_CFG="iso/isolinux/isolinux.cfg"
elif [[ -f iso/syslinux/isolinux.cfg ]]; then
  ISOLINUX_CFG="iso/syslinux/isolinux.cfg"
else
  echo "❌ isolinux.cfg not found in expected locations. Aborting."
  exit 1
fi

cp "$ISOLINUX_CFG" "$ISOLINUX_CFG.bak"

cat > "$ISOLINUX_CFG" <<EOF
UI menu.c32
PROMPT 0
TIMEOUT 300
DEFAULT backup

LABEL backup
  MENU LABEL Backup Manjaro to USB (auto)
  KERNEL /live/vmlinuz
  APPEND initrd=/live/initrd.img boot=live config keyboard-layouts=us locales=en_US.UTF-8 ocs_live_run="/home/partimag/manjaro_backup.sh" ocs_live_batch="yes" vga=788 noswap toram=filesystem.squashfs

LABEL restore
  MENU LABEL Restore Manjaro to Internal Disk (auto)
  KERNEL /live/vmlinuz
  APPEND initrd=/live/initrd.img boot=live config keyboard-layouts=us locales=en_US.UTF-8 ocs_live_run="/home/partimag/restore_to_nvme0n1.sh" ocs_live_batch="yes" vga=788 noswap toram=filesystem.squashfs
EOF

# 📆 Rebuild and flash ISO
echo "📆 Rebuilding filesystem..."
sudo mksquashfs extract newfilesystem.squashfs -e boot
sudo mv newfilesystem.squashfs iso/live/filesystem.squashfs

echo "📀 Building final ISO: $ISO_OUT"
if [[ -f iso/isolinux/isolinux.bin ]]; then
  BOOT_BIN="isolinux/isolinux.bin"
  BOOT_CAT="isolinux/boot.cat"
elif [[ -f iso/syslinux/isolinux.bin ]]; then
  BOOT_BIN="syslinux/isolinux.bin"
  BOOT_CAT="syslinux/boot.cat"
else
  echo "❌ isolinux.bin not found. Cannot make bootable ISO."
  exit 1
fi

xorriso -as mkisofs -r -V "CLONEZILLA_DUAL" \
  -J -l -b "$BOOT_BIN" -c "$BOOT_CAT" \
  -no-emul-boot -boot-load-size 4 -boot-info-table \
  -o "$ISO_OUT" iso


echo "⚠️ Flashing to USB: $BACKUP_USB (will erase all data)"
read -rp "Type YES to flash ISO to $BACKUP_USB: " confirm
[[ "$confirm" != "YES" ]] && echo "Cancelled." && exit 1

sudo dd if="$ISO_OUT" of="$BACKUP_USB" bs=4M status=progress oflag=sync

echo "✅ All done! Your USB now has:"
echo " - Backup mode (clones internal to USB)"
echo " - Restore mode (clones USB to internal)"
echo "Just boot from USB and choose the option you want."
