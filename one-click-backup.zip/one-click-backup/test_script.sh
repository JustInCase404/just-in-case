#!/bin/bash
# 🧪 SAFETY TEST: Clonezilla Backup Script Validator
# This script SIMULATES all actions without making changes.
# 📘 Use this to verify everything works before running the real one.

set -e

echo "🔍 Checking environment..."

# 🛠 Required tools
REQUIRED_TOOLS=(wget xorriso unsquashfs mksquashfs parted sgdisk mkfs.ext4 grub-install ocs-sr)
for tool in "${REQUIRED_TOOLS[@]}"; do
    if ! command -v "$tool" &>/dev/null; then
        echo "❌ ERROR: Required tool '$tool' is missing."
        exit 1
    fi
done
echo "✅ All required tools found."

# 📦 Variables
CLONEZILLA_ISO="clonezilla.iso"
WORKDIR="$HOME/clonezilla-work"
SOURCE_DISK="/dev/nvme1n1"
DEST_DISK="/dev/sda"

echo "📁 Checking for Clonezilla ISO at $WORKDIR/$CLONEZILLA_ISO..."
if [[ ! -f "$WORKDIR/$CLONEZILLA_ISO" ]]; then
    echo "⚠️ ISO not found — skipping ISO steps in this test."
else
    echo "✅ ISO exists."
fi

# 🛡️ SAFETY: Check that DEST_DISK is not a system drive
if mount | grep -q "$DEST_DISK"; then
    echo "❌ SAFETY CHECK FAILED: $DEST_DISK is currently mounted. This may be your system disk!"
    echo "🛑 Aborting test to prevent damage."
    exit 1
else
    echo "✅ Destination disk $DEST_DISK is not currently mounted."
fi

# 🧪 Simulate partitioning and formatting
echo "🧪 Simulating: Partition wipe and format on $DEST_DISK..."
echo "  - Would run: sgdisk --zap-all $DEST_DISK"
echo "  - Would run: parted -s $DEST_DISK mklabel gpt"
echo "  - Would run: parted -s $DEST_DISK mkpart primary 0% 100%"
echo "  - Would run: mkfs.ext4 ${DEST_DISK}1"

# 🧪 Simulate mount and clone
echo "🧪 Simulating: Mount and Clonezilla savedisk..."
echo "  - Would mount ${DEST_DISK}1 to /mnt/usb_backup"
echo "  - Would run Clonezilla savedisk from $SOURCE_DISK to $DEST_DISK"

# 🧪 Simulate bootloader
echo "🧪 Simulating: GRUB install..."
echo "  - Would chroot into /mnt/usb_backup and run grub-install"
echo "  - Would run update-grub"

# 🧹 Simulate cleanup
echo "🧪 Simulating: Unmount and cleanup..."
echo "  - Would unmount /mnt/usb_backup"

echo "✅ TEST COMPLETE: All steps simulated successfully."
echo "🚦 You can now safely run the full script with real actions if everything looks good."

