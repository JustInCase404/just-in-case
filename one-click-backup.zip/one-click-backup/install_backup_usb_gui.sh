#!/bin/bash
# 🧙 Installer for Manjaro USB Backup GUI

set -e

INSTALL_DIR="$HOME/one-click-backup"
DESKTOP_DIR="$HOME/Desktop"
ICON_NAME="usb-backup-icon.png"
DESKTOP_FILE="manjaro-usb-backup.desktop"

echo "📦 Creating install directory at $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"

echo "📁 Copying files..."
# Only copy if not already in the install dir
for file in backup_usb_gui.sh make_backup_usb.sh $ICON_NAME $DESKTOP_FILE; do
    if [[ "$(pwd)/$file" != "$INSTALL_DIR/$file" ]]; then
        cp "$file" "$INSTALL_DIR/"
    fi
done

echo "🔐 Making scripts executable..."
chmod +x "$INSTALL_DIR/backup_usb_gui.sh"
chmod +x "$INSTALL_DIR/make_backup_usb.sh"

echo "🖼️ Installing icon..."
cp "$ICON_NAME" "$INSTALL_DIR/"

echo "🧷 Creating desktop shortcut..."
cat > "$DESKTOP_DIR/$DESKTOP_FILE" <<EOF
[Desktop Entry]
Type=Application
Name=Manjaro USB Backup
Comment=One-click full backup to USB
Exec=bash -c 'sudo $INSTALL_DIR/backup_usb_gui.sh'
Icon=$INSTALL_DIR/$ICON_NAME
Terminal=true
Categories=Utility;
EOF

chmod +x "$DESKTOP_DIR/$DESKTOP_FILE"

echo "✅ Done! You can now double-click the Manjaro USB Backup icon on your desktop."
echo "🧠 Tip: If it doesn't launch, right-click the icon and choose 'Allow Launching'."

