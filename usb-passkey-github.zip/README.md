# USB Passkey 🔐

A secure, USB-triggered authentication system for local sudo access and Bitwarden integration.

## Features
- USB decryption and partition mounting
- SUDO password refresh via USB
- Bitwarden login session with stored master key
- QR-based 2FA for recovering secure credentials
- GUI manager (Tkinter-based)
- Debian + Arch packaging
- Systemd service & Desktop launcher

## Installation

```bash
chmod +x install/install-all.sh
sudo ./install/install-all.sh
```

## GUI

Launch from your Applications menu or run:

```bash
python3 /usr/local/bin/usb-passkey-gui.py
```

## Uninstall

```bash
sudo /usr/local/bin/uninstall-usb-passkey.sh
```

## Packaging

- For Debian:
```bash
cd install
./build-debian-package.sh
```

- For Arch:
```bash
makepkg -si
```

## License
MIT License
