#!/bin/bash

INSTALL_DIR="/usr/local/bin"
SYSTEMD_DIR="/etc/systemd/system"

# Scripts to install
scripts=(
    "setup-usb-partitions.py"
    "usbkey-auto-auth.py"
    "usbkey-startup.py"
    "usbkey-2fa.py"
    "usb-passkey-gui.py"
)

# Install scripts to /usr/local/bin
for script in "${scripts[@]}"; do
    echo "Installing $script to $INSTALL_DIR"
    sudo cp "$script" "$INSTALL_DIR"
    sudo chmod +x "$INSTALL_DIR/$script"
done

# Install systemd service
echo "Installing usbkey.service"
sudo cp usbkey.service "$SYSTEMD_DIR"
sudo systemctl daemon-reexec
sudo systemctl enable usbkey.service
sudo systemctl start usbkey.service

# Create log file if it doesn't exist
LOG_FILE="/var/log/usb_passkey_auth.log"
if [ ! -f "$LOG_FILE" ]; then
    sudo touch "$LOG_FILE"
    sudo chmod 644 "$LOG_FILE"
fi

echo "📅 USB Passkey system installed."
