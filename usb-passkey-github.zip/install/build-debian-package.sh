#!/bin/bash

# Build a Debian package for the USB Passkey system

mkdir -p usb-passkey_1.0/usr/local/bin
mkdir -p usb-passkey_1.0/etc/systemd/system
mkdir -p usb-passkey_1.0/usr/share/applications
mkdir -p usb-passkey_1.0/usr/share/icons/hicolor/128x128/apps

cp setup-usb-partitions.py usb-passkey_1.0/usr/local/bin/
cp usbkey-auto-auth.py usb-passkey_1.0/usr/local/bin/
cp usbkey-startup.py usb-passkey_1.0/usr/local/bin/
cp usbkey-2fa.py usb-passkey_1.0/usr/local/bin/
cp usb-passkey-gui.py usb-passkey_1.0/usr/local/bin/

cp usbkey.service usb-passkey_1.0/etc/systemd/system/
cp usb-passkey.desktop usb-passkey_1.0/usr/share/applications/
cp usb-passkey.svg usb-passkey_1.0/usr/share/icons/hicolor/128x128/apps/

mkdir -p usb-passkey_1.0/DEBIAN
cat <<EOF > usb-passkey_1.0/DEBIAN/control
Package: usb-passkey
Version: 1.0
Section: base
Priority: optional
Architecture: all
Depends: python3, python3-pyotp, python3-qrcode, x11-utils
Maintainer: USB_PASSKEY Team
Description: Secure USB authentication and Bitwarden integration tool
EOF

dpkg-deb --build usb-passkey_1.0

echo "📅 Debian package built: usb-passkey_1.0.deb"
