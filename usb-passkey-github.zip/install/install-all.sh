#!/bin/bash

set -e

echo "🔧 Installing USB Passkey System..."

# Make scripts executable
chmod +x install-usb-passkey.sh uninstall-usb-passkey.sh build-debian-package.sh

# Copy scripts to /usr/local/bin
echo "📦 Copying core scripts to /usr/local/bin..."
sudo install -m 755 usbkey-auto-auth.py /usr/local/bin/
sudo install -m 755 usbkey-startup.py /usr/local/bin/
sudo install -m 755 usbkey-2fa.py /usr/local/bin/
sudo install -m 755 setup-usb-partitions.py /usr/local/bin/
sudo install -m 755 usb-passkey-gui.py /usr/local/bin/

# Copy service file
echo "🛠️ Installing systemd service..."
sudo cp usbkey.service /etc/systemd/system/
sudo systemctl daemon-reexec
sudo systemctl enable usbkey.service

# Desktop and icon
echo "🖼️ Installing GUI launcher and icon..."
sudo cp usb-passkey.desktop /usr/share/applications/
sudo cp usb-passkey.svg /usr/share/icons/hicolor/128x128/apps/
sudo gtk-update-icon-cache /usr/share/icons/hicolor
chmod +x /usr/share/applications/usb-passkey.desktop

# Setup log directory
echo "📁 Creating log directory..."
sudo mkdir -p /var/log
sudo touch /var/log/usb_passkey_auth.log
sudo chmod 644 /var/log/usb_passkey_auth.log

echo "✅ Installation complete. Run with:"
echo "   python3 /usr/local/bin/usb-passkey-gui.py"
