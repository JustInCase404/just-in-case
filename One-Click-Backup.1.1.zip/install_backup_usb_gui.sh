#!/bin/bash
# 🧙 Installer for Manjaro USB Backup GUI

set -e

INSTALL_DIR="$HOME/one-click-backup"
DESKTOP_DIR="$HOME/Desktop"
ICON_NAME="usb-backup-icon.svg"
DESKTOP_FILE="manjaro-usb-backup.desktop"

echo "📦 Creating install directory at $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"

echo "📁 Copying files..."
for file in backup_usb_gui.sh make_backup_usb.sh $ICON_NAME $DESKTOP_FILE; do
    if [[ -f "$file" ]]; then
        cp "$file" "$INSTALL_DIR/"
    else
        echo "⚠️ Warning: File $file not found, skipping."
    fi
done

echo "🔧 Making launcher executable..."
chmod +x "$INSTALL_DIR/backup_usb_gui.sh"

echo "🖼 Installing icon..."
sudo mkdir -p /usr/share/icons/hicolor/scalable/apps/
sudo cp "$INSTALL_DIR/$ICON_NAME" /usr/share/icons/hicolor/scalable/apps/

echo "🖥️ Creating desktop launcher..."
cp "$INSTALL_DIR/$DESKTOP_FILE" "$DESKTOP_DIR/"
chmod +x "$DESKTOP_DIR/$DESKTOP_FILE"

echo "✅ Installation complete!"
echo "💡 Tip: You can now launch the backup tool from your Desktop."

