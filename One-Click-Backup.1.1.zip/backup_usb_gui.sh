#!/bin/bash
# 🧙 GUI Launcher for Manjaro USB Backup
#!/bin/bash
set -e

# 🧩 Dependencies check
for cmd in zenity xterm; do
    if ! command -v "$cmd" &>/dev/null; then
        zenity --error --text="$cmd is required but not installed.\n\nRun:\n  sudo pacman -S $cmd"
        exit 1
    fi
done

# 🖼 Icon setup
ICON_PATH="/usr/share/icons/hicolor/scalable/apps/usb-backup-icon.svg"
[[ ! -f "$ICON_PATH" ]] && ICON_PATH=""

# 🔍 Locate main backup script
BACKUP_SCRIPT="/usr/bin/make_backup_usb.sh"

# 🧪 If not found, fallback to ~/one-click-backup
[[ ! -x "$BACKUP_SCRIPT" ]] && BACKUP_SCRIPT="$HOME/one-click-backup/make_backup_usb.sh"

if [[ ! -x "$BACKUP_SCRIPT" ]]; then
    zenity --error --text="Backup script not found!\nExpected at:\n  /usr/bin/make_backup_usb.sh or ~/one-click-backup"
    exit 1
fi

# 📋 Show main menu
ACTION=$(zenity --list \
    --title="🧰 Manjaro USB Backup Tool" \
    --width=600 --height=400 \
    --text="<big><b>Select an action:</b></big>" \
    --column="Action" \
    "🔄 Create Bootable Backup USB" \
    "♻️ Restore System from USB" \
    "❌ Exit" \
    --window-icon="$ICON_PATH" \
    --ok-label="Run")

# 🎬 Handle action
case "$ACTION" in
    "🔄 Create Bootable Backup USB")
        zenity --question --title="Are you sure?" \
            --text="This will ERASE your USB and create a full system backup.\n\nContinue?" \
            --width=400 || exit 0
        xterm -bg black -fg white -fa Monospace -fs 11 -hold -e "sudo $BACKUP_SCRIPT"
        ;;
    "♻️ Restore System from USB")
        zenity --info \
            --title="Restore Instructions" \
            --width=400 \
            --text="🧯 To restore your system, please:\n\n1. Reboot your PC\n2. Boot from the USB drive\n3. Choose 'Restore System to Internal Disk'\n\nThe process is fully automated."
        ;;
    *)
        echo "Cancelled."
        ;;
esac
