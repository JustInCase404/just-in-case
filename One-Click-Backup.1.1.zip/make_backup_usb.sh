#!/bin/bash
# 🎯 Final Merged Script: One-Click Manjaro Backup USB Creator with Full Clonezilla Live ISO + Auto Scripts
set -e

# 🧾 Enable logging to file
LOG="$HOME/backup_usb_build.log"
exec > >(tee -i "$LOG") 2>&1

echo "⏰ Started at: $(date)"

[[ $EUID -ne 0 ]] && echo "❌ Please run as root." && exit 1


### --- Configuration ------------------------------
SOURCE_DISK="/dev/nvme1n1"
BACKUP_USB="/dev/sdb"
RESTORE_TARGET="/dev/nvme0n1"
WORKDIR="$HOME/clonezilla-work"
CLONEZILLA_URL="https://downloads.sourceforge.net/project/clonezilla/clonezilla_live_stable/3.1.2-9/clonezilla-live-3.1.2-9-amd64.iso"
ISO_NAME="clonezilla.iso"
ISO_OUT="clonezilla-dualboot.iso"
### ------------------------------------------------

echo "📦 Preparing working directory..."
mkdir -p "$WORKDIR"
cd "$WORKDIR"

echo "⏏️ Unmounting any existing mounts..."
sudo umount -l mnt 2>/dev/null || true

echo "🧹 Cleaning previous build..."
sudo rm -rf mnt iso extract squashfs-root newfilesystem.squashfs
mkdir -p mnt iso extract

echo "🌐 Downloading Clonezilla ISO..."
wget -O "$ISO_NAME" "$CLONEZILLA_URL"

echo "📂 Mounting Clonezilla ISO..."
sudo mount -o loop "$ISO_NAME" mnt

echo "📥 Copying full ISO contents..."
cp -a mnt/* iso/

echo "🔍 Verifying kernel and initrd presence..."
if [[ ! -f iso/live/vmlinuz || ! -f iso/live/initrd.img ]]; then
  echo "❌ ERROR: Kernel or initrd not found in iso/live/. Aborting."
  exit 1
else
  echo "✅ Kernel and initrd verified in iso/live/"
fi

echo "📦 Extracting squashfs filesystem..."
sudo unsquashfs mnt/live/filesystem.squashfs
cp -r squashfs-root extract
sudo umount mnt

echo "📝 Adding backup and restore scripts..."
sudo mkdir -p extract/home/partimag

# 🔄 Backup script
cat <<EOF | sudo tee extract/home/partimag/manjaro_backup.sh >/dev/null
#!/bin/bash
set -e
SOURCE_DISK="$SOURCE_DISK"
DEST_DISK="$BACKUP_USB"
echo "⚠️ This will ERASE \$DEST_DISK and clone \$SOURCE_DISK onto it."
read -rp "Type YES to continue: " confirm
[[ "\$confirm" != "YES" ]] && echo "Cancelled." && exit 1
sgdisk --zap-all "\$DEST_DISK"
parted -s "\$DEST_DISK" mklabel gpt
parted -s "\$DEST_DISK" mkpart primary 0% 100%
sleep 2
mkfs.ext4 "\${DEST_DISK}1" -L manjaro_backup
mount "\${DEST_DISK}1" /mnt
ocs-sr -q2 -j2 -z1p -i 2000 -sc -sfsck savedisk "manjaro_clone" "\$SOURCE_DISK"
mount --bind /dev /mnt/dev
mount --bind /proc /mnt/proc
mount --bind /sys /mnt/sys
chroot /mnt grub-install --target=i386-pc --recheck "\$DEST_DISK"
chroot /mnt update-grub
umount -R /mnt
echo "✅ Backup complete."
EOF

# ♻️ Restore script
cat <<EOF | sudo tee extract/home/partimag/restore_to_nvme0n1.sh >/dev/null
#!/bin/bash
set -e
SOURCE_DISK="$BACKUP_USB"
DEST_DISK="$RESTORE_TARGET"
echo "⚠️ This will ERASE \$DEST_DISK and restore Manjaro from \$SOURCE_DISK."
read -rp "Type YES to continue: " confirm
[[ "\$confirm" != "YES" ]] && echo "Cancelled." && exit 1
sgdisk --zap-all "\$DEST_DISK"
parted -s "\$DEST_DISK" mklabel gpt
parted -s "\$DEST_DISK" mkpart primary 0% 100%
sleep 2
mkfs.ext4 "\${DEST_DISK}1" -L manjaro_restored
mount "\${DEST_DISK}1" /mnt
ocs-sr -g auto -e1 auto -e2 -r -j2 -k1 -p true -scr -icds restoredisk "manjaro_clone" "\$DEST_DISK"
mount --bind /dev /mnt/dev
mount --bind /proc /mnt/proc
mount --bind /sys /mnt/sys
chroot /mnt grub-install --target=i386-pc --recheck "\$DEST_DISK"
chroot /mnt update-grub
umount -R /mnt
echo "✅ Restore complete."
EOF

sudo chmod +x extract/home/partimag/*.sh

echo "🧠 Patching GRUB for UEFI boot menu..."
GRUB_CFG="iso/boot/grub/grub.cfg"
if [[ -f "$GRUB_CFG" ]]; then
  cp "$GRUB_CFG" "$GRUB_CFG.bak"
  cat >> "$GRUB_CFG" <<EOF

menuentry "🔄 Backup Manjaro to USB (auto)" {
  search --set=root --label backup_root
  linux /live/vmlinuz boot=live config keyboard-layouts=us locales=en_US.UTF-8 ocs_live_run="/home/partimag/manjaro_backup.sh" ocs_live_batch="yes" vga=788 noswap toram=filesystem.squashfs
  initrd /live/initrd.img
}

menuentry "♻️ Restore Manjaro to Internal Disk (auto)" {
  search --set=root --label backup_root
  linux /live/vmlinuz boot=live config keyboard-layouts=us locales=en_US.UTF-8 ocs_live_run="/home/partimag/restore_to_nvme0n1.sh" ocs_live_batch="yes" vga=788 noswap toram=filesystem.squashfs
  initrd /live/initrd.img
}
EOF
fi

echo "🦝 Updating boot menu for BIOS (isolinux)..."
if [[ -f iso/isolinux/isolinux.cfg ]]; then
  ISOLINUX_CFG="iso/isolinux/isolinux.cfg"
elif [[ -f iso/syslinux/isolinux.cfg ]]; then
  ISOLINUX_CFG="iso/syslinux/isolinux.cfg"
else
  echo "❌ isolinux.cfg not found!"
  exit 1
fi


cp "$ISOLINUX_CFG" "$ISOLINUX_CFG.bak"
cat >> "$ISOLINUX_CFG" <<EOF

UI menu.c32
PROMPT 0
TIMEOUT 300
DEFAULT backup

LABEL backup
  MENU LABEL Backup Manjaro to USB (auto)
  KERNEL /live/vmlinuz
  APPEND initrd=/live/initrd.img boot=live config keyboard-layouts=us locales=en_US.UTF-8 ocs_live_run="/home/partimag/manjaro_backup.sh" ocs_live_batch="yes" vga=788 noswap toram=filesystem.squashfs

LABEL restore
  MENU LABEL Restore Manjaro to Internal Disk (auto)
  KERNEL /live/vmlinuz
  APPEND initrd=/live/initrd.img boot=live config keyboard-layouts=us locales=en_US.UTF-8 ocs_live_run="/home/partimag/restore_to_nvme0n1.sh" ocs_live_batch="yes" vga=788 noswap toram=filesystem.squashfs
EOF

echo "📦 Rebuilding squashfs..."
sudo mksquashfs extract newfilesystem.squashfs -e boot
sudo mv newfilesystem.squashfs iso/live/filesystem.squashfs

echo "📦 Locating isolinux boot files..."
if [[ -f iso/isolinux/isolinux.bin ]]; then
  BOOT_BIN="isolinux/isolinux.bin"
  BOOT_CAT="isolinux/boot.cat"
elif [[ -f iso/syslinux/isolinux.bin ]]; then
  BOOT_BIN="syslinux/isolinux.bin"
  BOOT_CAT="syslinux/boot.cat"
else
  echo "❌ isolinux.bin not found. Cannot make bootable ISO."
  exit 1
fi

echo "📀 Creating final ISO: $ISO_OUT"
xorriso -as mkisofs -r -V "CLONEZILLA_DUAL" \
  -J -l -b "$BOOT_BIN" -c "$BOOT_CAT" \
  -no-emul-boot -boot-load-size 4 -boot-info-table \
  -o "$ISO_OUT" iso

echo "⚠️ This will ERASE all data on $BACKUP_USB"
read -rp "Type YES to continue flashing USB: " confirm
[[ "$confirm" != "YES" ]] && echo "Cancelled." && exit 1

echo "💽 Partitioning USB..."
sudo wipefs -a "$BACKUP_USB"
sudo parted "$BACKUP_USB" --script mklabel gpt
sudo parted "$BACKUP_USB" --script mkpart ESP fat32 1MiB 512MiB
sudo parted "$BACKUP_USB" --script set 1 esp on
sudo parted "$BACKUP_USB" --script mkpart primary ext4 512MiB 100%
sleep 2

sudo mkfs.fat -F32 "${BACKUP_USB}1" -n EFI
sudo mkfs.ext4 "${BACKUP_USB}2" -L backup_root

echo "📁 Copying ISO contents to USB..."
mkdir -p /mnt/usb_efi /mnt/usb_data
sudo mount "${BACKUP_USB}1" /mnt/usb_efi
sudo mount "${BACKUP_USB}2" /mnt/usb_data
sudo cp -r iso/EFI /mnt/usb_efi/ 2>/dev/null || true
sudo cp -r iso/boot /mnt/usb_efi/ 2>/dev/null || true
sudo cp -r iso/* /mnt/usb_data/
sudo rm -rf /mnt/usb_data/EFI /mnt/usb_data/boot

echo "⚙️ Installing GRUB for UEFI boot..."
sudo grub-install   --target=x86_64-efi   --efi-directory=/mnt/usb_efi   --boot-directory=/mnt/usb_efi/boot   --removable   --recheck   "$BACKUP_USB"

sudo umount /mnt/usb_efi /mnt/usb_data
rm -rf /mnt/usb_efi /mnt/usb_data

echo "🧹 Cleaning working directory..."
rm -rf "$WORKDIR"

echo "✅ USB ready! Fully bootable with Clonezilla + backup & restore automation."
echo "💡 Tip: Boot your system and select Backup or Restore from the menu."
echo "📄 Full build log saved to: $LOG"

echo "⏰ Finished at: $(date)"

# xdg-open "$LOG" &> /dev/null &

