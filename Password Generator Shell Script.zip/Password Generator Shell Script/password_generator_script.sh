#!/bin/bash

set -e

# -----------------------------------
# CONFIGURATION
# -----------------------------------
SCRIPT_DIR="$(dirname \"$(readlink -f \"$0\")\")"
CONFIG_FILE="$SCRIPT_DIR/.encryption_config"
ENCRYPTED_FILE="$SCRIPT_DIR/encrypted_password.tar.gz.enc"
TEMP_DIR=$(mktemp -d)
PASSWORD_JSON="$TEMP_DIR/password.json"

# -----------------------------------
# Install Dependencies
# -----------------------------------
install_dependencies() {
    dependencies=("jq" "zenity" "openssl" "tar" "xclip")

    if command -v pacman &> /dev/null; then
        sudo pacman -S --noconfirm "${dependencies[@]}"
    elif command -v apt &> /dev/null; then
        sudo apt install -y "${dependencies[@]}"
    else
        zenity --error --text="❌ Unsupported package manager. Install manually."
        exit 1
    fi
}

install_dependencies

# -----------------------------------
# Generate Encryption Key (if doesn't exist)
# -----------------------------------
if [[ ! -f "$CONFIG_FILE" ]]; then
    ENCRYPTION_PASSWORD=$(tr -dc 'A-Za-z0-9!@#$%^&*_+=' < /dev/urandom | head -c 32)
    echo "ENCRYPTION_PASSWORD='$ENCRYPTION_PASSWORD'" > "$CONFIG_FILE"
    chmod 600 "$CONFIG_FILE"
else
    source "$CONFIG_FILE"
fi

# -----------------------------------
# Generate secure password
# -----------------------------------
PASSWORD_VALUE=$(tr -dc 'A-Za-z0-9!@#$%^&*_+=' < /dev/urandom | head -c 16)
echo -n "$PASSWORD_VALUE" | xclip -selection clipboard

zenity --info --title="Password Generated" --text="✅ Secure password generated and copied to clipboard."

# -----------------------------------
# Save password to JSON
# -----------------------------------
echo "{\"password\": \"$PASSWORD_VALUE\"}" > "$PASSWORD_JSON"

# -----------------------------------
# Encrypt the password JSON
# -----------------------------------
tar -czf "$TEMP_DIR/password.tar.gz" -C "$TEMP_DIR" "$(basename "$PASSWORD_JSON")"
openssl enc -aes-256-cbc -salt -pbkdf2 -in "$TEMP_DIR/password.tar.gz" -out "$ENCRYPTED_FILE" -pass pass:"$ENCRYPTION_PASSWORD"

# -----------------------------------
# Cleanup
# -----------------------------------
rm -rf "$TEMP_DIR"

zenity --info --title="Password Archived" --width=400 \
    --text="✅ Password securely archived at:\n$ENCRYPTED_FILE"

