#!/bin/bash

set -e

# -----------------------------------
# CONFIGURATION
# -----------------------------------
SCRIPT_DIR="$(dirname \"$(readlink -f \"$0\")\")"
CONFIG_FILE="$SCRIPT_DIR/.encryption_config"
ICON_PATH="$SCRIPT_DIR/password-generator.png"
DESKTOP_FILE="$HOME/.local/share/applications/retrieve_password.desktop"

# Load ENCRYPTION_PASSWORD from configuration
if [[ -f "$CONFIG_FILE" ]]; then
    source "$CONFIG_FILE"
else
    zenity --error --text="❌ Encryption configuration file missing. Please run password_generator_script.sh first."
    exit 1
fi

# -----------------------------------
# Install Dependencies
# -----------------------------------
install_dependencies() {
    dependencies=("jq" "zenity" "xclip" "openssl" "tar")

    if command -v pacman &> /dev/null; then
        sudo pacman -S --noconfirm "${dependencies[@]}"
    elif command -v apt &> /dev/null; then
        sudo apt install -y "${dependencies[@]}"
    else
        zenity --error --text="❌ Unsupported distro. Install manually: ${dependencies[*]}"
        exit 1
    fi
}

install_dependencies

# -----------------------------------
# GUI to Upload Encrypted File
# -----------------------------------
ENCRYPTED_FILE=$(zenity --file-selection --title="Select Encrypted Archive (encrypted.tar.gz.enc)")

if [[ ! -f "$ENCRYPTED_FILE" ]]; then
    zenity --error --text="❌ No file selected or file does not exist!"
    exit 1
fi

# Temporary directory for decryption
temp_dir=$(mktemp -d)

# Decrypt and extract the archive
openssl enc -d -aes-256-cbc -pbkdf2 -in "$ENCRYPTED_FILE" -out "$temp_dir/decrypted.tar.gz" -pass pass:"$ENCRYPTION_PASSWORD" || {
    zenity --error --text="❌ Decryption failed! Wrong password or corrupted file."
    rm -rf "$temp_dir"
    exit 1
}

# Extract archive
tar -xzf "$temp_dir/decrypted.tar.gz" -C "$temp_dir"

# Retrieve the password
RETRIEVED_PASSWORD=$(jq -r '.password' "$temp_dir/encrypted/password.json")

# Cleanup temporary files
rm -rf "$temp_dir"

# Copy password to clipboard (never show)
echo -n "$RETRIEVED_PASSWORD" | xclip -selection clipboard

zenity --info --title="Password Retrieved" --text="✅ Password retrieved and copied to clipboard."

# -----------------------------------
# Create Desktop Launcher
# -----------------------------------
mkdir -p "$(dirname \"$DESKTOP_FILE\")"

cat << EOF > "$DESKTOP_FILE"
[Desktop Entry]
Name=Retrieve Password
Comment=Retrieve and copy password from encrypted archive
Exec=$SCRIPT_DIR/$(basename "$0")
Icon=$ICON_PATH
Terminal=false
Type=Application
Categories=Utility;
EOF

chmod +x "$DESKTOP_FILE"

zenity --info --title="Desktop Launcher Created" --text="✅ Launcher created at:\n$DESKTOP_FILE"

