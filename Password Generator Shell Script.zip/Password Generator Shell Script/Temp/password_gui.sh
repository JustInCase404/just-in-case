#!/bin/bash

# Function to generate a strong password
generate_password() {
  # Generate a password with 16 characters, including uppercase, lowercase, numbers, and special characters
  PASSWORD=$(tr -dc 'A-Za-z0-9_@#!$%^&*()_+' < /dev/urandom | head -c 16)
  echo $PASSWORD
}

# Generate the password
PASSWORD=$(generate_password)

# Display password in a Zenity entry dialog (this is not visible in the dialog, user can copy it)
zenity --info --title="Password Generated" --text="Your password has been generated. You can copy it now." --ok-label="Copy" --extra-button="Copy" --extra-button="Cancel" \
--clipboard=$PASSWORD

