#!/bin/bash

# Function to generate a strong password
generate_password() {
  # Generate a password with 16 characters, including uppercase, lowercase, numbers, and special characters
  PASSWORD=$(tr -dc 'A-Za-z0-9_@#!$%^&*()_+' < /dev/urandom | head -c 16)
  echo $PASSWORD
}

# Run the function
generate_password

