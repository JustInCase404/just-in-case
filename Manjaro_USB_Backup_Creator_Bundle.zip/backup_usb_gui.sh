#!/bin/bash
# 🧙‍♂️ GUI Wrapper for make_backup_usb.sh

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
SCRIPT="$SCRIPT_DIR/make_backup_usb.sh"

zenity --question \
  --width=400 \
  --title="Manjaro Backup USB Creator" \
  --text="This will erase your 128GB USB and create a full backup.\n\nAre you sure you want to continue?"

if [[ $? -eq 0 ]]; then
  # Run the real script in terminal
  gnome-terminal -- bash -c "sudo \"$SCRIPT\"; echo 'Done! Press any key to exit...'; read -n 1"
else
  zenity --info --text="Backup canceled."
fi

