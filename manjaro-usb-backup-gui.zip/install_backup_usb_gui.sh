#!/bin/bash
# 🧙 One-time setup: install the Manjaro USB Backup GUI into your system menu

INSTALL_DIR="$HOME/one-click-backup"
DESKTOP_FILE="manjaro-usb-backup.desktop"
GUI_SCRIPT="backup_usb_gui.sh"
ICON_FILE="usb_backup_icon.png"  # Optional custom icon

echo "📦 Creating install directory at $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"

echo "📁 Copying files..."
cp "$GUI_SCRIPT" "$INSTALL_DIR/"
cp "make_backup_usb.sh" "$INSTALL_DIR/"
cp "$DESKTOP_FILE" "$INSTALL_DIR/"

# Optional: copy the icon if it exists
if [[ -f "$ICON_FILE" ]]; then
    cp "$ICON_FILE" "$INSTALL_DIR/"
    ICON_PATH="$INSTALL_DIR/$ICON_FILE"
else
    ICON_PATH="drive-removable-media-usb"
fi

echo "🔧 Making scripts executable..."
chmod +x "$INSTALL_DIR/$GUI_SCRIPT"
chmod +x "$INSTALL_DIR/make_backup_usb.sh"

echo "🖼️ Updating desktop launcher with full path..."
# Replace placeholder in .desktop with real path
sed "s|Exec=.*|Exec=$INSTALL_DIR/$GUI_SCRIPT|" "$INSTALL_DIR/$DESKTOP_FILE" | \
sed "s|Icon=.*|Icon=$ICON_PATH|" > "$INSTALL_DIR/$DESKTOP_FILE.updated"

mv "$INSTALL_DIR/$DESKTOP_FILE.updated" "$INSTALL_DIR/$DESKTOP_FILE"

echo "🚀 Installing desktop launcher to your app menu..."
cp "$INSTALL_DIR/$DESKTOP_FILE" ~/.local/share/applications/

echo "✅ Done! Launch 'Manjaro USB Backup Tool' from your app menu."

